package com.example.socket_test;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
        ImageView image;
        TextView name;
}

