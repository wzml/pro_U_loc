package com.example.login_server.UserInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class addFriendUtils {

    //socket连接服务器判断是否存在id用户，返回其name
    public String[] findserver(String myid,String id,String num) throws IOException {
        Socket socket  = new Socket();
        socket.connect(new InetSocketAddress("118.31.61.122",7327),6000);
        //to server
        OutputStream os = socket.getOutputStream();
        PrintWriter pw = new PrintWriter(os);
        //from server
        InputStreamReader Socin = new InputStreamReader(socket.getInputStream());
        BufferedReader SocBuf = new BufferedReader(Socin);

        System.out.println(num);
        //1表示查找，后面接id
        if(num.equals("1"))
        {
            pw.write(1+"\n");
            pw.flush();
            pw.write(id+"\n");
            pw.flush();
        } else if(num.equals("2")){   //2表示添加好友发送申请
            pw.write(2+"\n");
            pw.flush();
            pw.write(myid+"\n");
            pw.flush();
            pw.write(id+"\n");
            pw.flush();
        } else if(num.equals("3")){  //查找好友信息
            pw.write(3+"\n");
            pw.flush();
            System.out.println(myid);
            pw.write(myid+"\n");
            pw.flush();
        } else {         //4,查找被邀请好友姓名列表
            pw.write(4+"\n");
            pw.flush();
            pw.write(myid+"\n");
            pw.flush();
        }

        String name[] = new String[10];
        if(num.equals("3")){    //返回name（昵称）数组
            int i = 0;
            String name1 = SocBuf.readLine();
            while(!name1.equals("F")){ //服务器传来的值不是F就一直获取好友姓名
                if(!name1.equals(""))
                    name[i] = name1;
                //name[i] = name1;
                System.out.println(name1);
                if(!name1.equals(""))//不等于“”才自加
                    i++;
                name1 = SocBuf.readLine();
            }
            name[i] = "F";
        }else if(num.equals("4")){
            int i = 0;
            String name1 = SocBuf.readLine();
            while(!name1.equals("F")){ //服务器传来的值不是F就一直获取好友姓名
                if(!name1.equals("")) {
                    name[i] = name1;
                    i++;
                }
                name1 = SocBuf.readLine();
            }
            name[i] = "F";
        } else{
           name[0] = SocBuf.readLine();
           System.out.println(name[0]);
        }
        os.close();
        Socin.close();
        socket.close();
        return name;
    }

    public String invite(String myid, String name, int num) throws IOException{
        Socket socket  = new Socket();
        socket.connect(new InetSocketAddress("118.31.61.122",7327),6000);
        //to server
        OutputStream os = socket.getOutputStream();
        PrintWriter pw = new PrintWriter(os);
        //from server
        InputStreamReader Socin = new InputStreamReader(socket.getInputStream());
        BufferedReader SocBuf = new BufferedReader(Socin);

        System.out.println(num);
        //根据输入num服务器对数据库进行不同操作
        pw.write(num+"\n");pw.flush();
        pw.write(myid+"\n");pw.flush();
        pw.write(name+"\n");pw.flush();
        //返回数据库是否操作成功
        String res = "F";
        res = SocBuf.readLine();  //获取操控结果
        System.out.println(res);
        os.close();
        Socin.close();
        socket.close();
        return res;
    }

    //输入myid，好友name，查找添加状态--服务端还未添加响应操作
    public String findCondi(String myid, String name) throws IOException{
        String conDi = null;
        Socket socket  = new Socket();
        socket.connect(new InetSocketAddress("118.31.61.122",7327),6000);
        //to server
        OutputStream os = socket.getOutputStream();
        PrintWriter pw = new PrintWriter(os);
        //from server
        InputStreamReader Socin = new InputStreamReader(socket.getInputStream());
        BufferedReader SocBuf = new BufferedReader(Socin);
        int num = 13;  //13表示查找用户名为
        System.out.println(num);
        //根据输入num服务器对数据库进行不同操作
        pw.write(num+"\n");pw.flush();
        pw.write(myid+"\n");pw.flush();
        pw.write(name+"\n");pw.flush();
        //返回数据库是否操作成功
        conDi = SocBuf.readLine();  //获取操控结果
        System.out.println(conDi);
        os.close();
        Socin.close();
        socket.close();
        return conDi;
    }

    //

}
