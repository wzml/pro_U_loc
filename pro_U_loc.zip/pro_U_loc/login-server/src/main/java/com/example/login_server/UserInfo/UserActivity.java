package com.example.login_server.UserInfo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.login_server.R;
import com.example.login_server.UserInfo.fri_list.Fri;
import com.example.login_server.UserInfo.fri_list.FriAdaopter;
import com.example.login_server.service_saveLoc.Service_sentLocTag;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class UserActivity extends AppCompatActivity {
    private ListView lvfri;
    boolean stopThread = false;
    private FriAdaopter friAdaopter;
    private List<Fri> friList = new ArrayList<Fri>();  //创建集合保存好友信息

    //  获取定位信息相关
    Intent intent;
    LocationManager lm ;
    String loc;
    private double locj;
    private double locw;
    ServiceConnection conn = null;
    final static int LOCATION_SETTING_REQUEST_CODE = 100;

    private String id;
    private String name;
    private String[] names = new String[10];
    private ImageView iv_contact_red;
    private  LinearLayout ll_contact_invite;
    public String[] res = new String[10]; //好友申请表，最后一个为F

    private Timer timer;
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            if(msg.what == 0){
                //充复执行的代码
                //Toast.makeText(MainActivity.this,"演示",Toast.LENGTH_LONG).show();
                //获取好友邀请信息

                if(!stopThread){
                    new Thread(){
                        public void run() {
                            try{
                                addFriendUtils adf = new addFriendUtils();
                                res = adf.findserver(id,null,"4");
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                        }
                    }.start();
                }
                int i = 0;
                String namep = "F";
                if(res[i] != null)
                    namep = res[i];
                if(!namep.equals("F")){
                    i++;
                }
                if(i == 0) { //没有好友邀请
                    iv_contact_red.setVisibility(View.GONE);//默认不显示，如果显示就是visible
                } else {
                    iv_contact_red.setVisibility(View.VISIBLE);
                }

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        final Intent intent = getIntent();
        id = intent.getStringExtra("id"); //接收参数名为username的参数
        System.out.println(id);
        //好友信息显示
        lvfri = (ListView)findViewById(R.id.list_fri); //获得子布局
        getData();
        initAdaopter();
        FriAdaopter friAdaopter = new FriAdaopter(UserActivity.this,R.layout.listview_item,friList); //关联数据和子布局
        lvfri.setAdapter(friAdaopter);  //绑定数据和适配器

        //好友列表项点击事件
        lvfri.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Fri fri = friList.get(position);
                Toast.makeText(UserActivity.this,fri.getName(),Toast.LENGTH_LONG).show();
            }
        });

        //获得红点对象
        iv_contact_red =(ImageView ) findViewById(R.id.iv_contact_red);
        iv_contact_red.setVisibility(View.GONE);//默认不显示，如果显示就是visible
        initView(); //加载布局----好友邀请显示
        // 获取邀请信息条目对象
        ll_contact_invite = findViewById(R.id.ll_contact_invite);
        //邀请信息条目点击事件
        ll_contact_invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //红点处理--处理事件后红点消失
                iv_contact_red.setVisibility(View.GONE);
                //跳转到邀请信息列表页面
                Intent intent1 = new Intent(UserActivity.this, InviteActivity.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("inviteName",res);//传递数组res
                bundle.putString("myid",id);//传递当前用户id
                intent1.putExtras(bundle);
                startActivity(intent1);

                refresh();
            }
        });
        //动态申请危险权限
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            //onRequestPermissionsResult();  为了请求权限，为了让权限授予时立即生效，一般需要重写权限回调方法
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            prepareLocatingService();
        }
        serviceStart();
    }

//    @Override  //暂停activity时将stopthread置true，将结束线程
//    protected void onPause() {
//        stopThread=true;  //结束timer里面的线程
//        //timer.cancel();   //销毁timer
//        super.onPause();
//    }

    @Override
    protected void onStart() {
        stopThread=false;
        super.onStart();
    }

    @Override          //销毁activity时将stopthread置true，将结束线程
    protected void onDestroy() {
        super.onDestroy();
        stopThread=true;  //结束timer里面的线程
        timer.cancel();   //销毁timer
        if(intent!=null) {
            unbindService(conn);  // 解除绑定
            stopService(intent);
        }
        finish();
    }

    private void initAdaopter() {
        friAdaopter = new FriAdaopter(this,R.drawable.show_fri,friList);
    }

    private void refresh() {
        //获得数据库所有好友列表信息
        getData();
        //刷新适配器
        friAdaopter.refresh(friList);
    }


    //周期性执行线程，延迟0，周期：60*1000=1min即是60s跑一次线程
    private void initView() {   //红点对象是否显示
        //红点是否显示取决于是否有好友邀请信息-----需要每隔一段时间就跑跑线程查看好友邀请信息
        //每隔1min扫描一下红点对象是否显示
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Message message = new Message();
                message.what = 0;
                mHandler.sendMessage(message);
            }
        },0,60*1000);
    }

    private void getData() {
        while(names[0] == null)  //最差都有一个F-------跑线程来获取好友名称
        {
            findfris("3");
        }
        int[] imageIds = {
                R.drawable.show_fri,R.drawable.show_fri,
                R.drawable.show_fri,R.drawable.show_fri,
                R.drawable.show_fri,R.drawable.show_fri,
                R.drawable.show_fri,R.drawable.show_fri,
                R.drawable.show_fri,R.drawable.show_fri
        };
        int i = 0;
        //System.out.println(names[0]);
        //System.out.println(names[1]);
        String namep = "F";
        if(names[i] != null)
            namep = names[i];
        while(!namep.equals("F")){
            i++;
            namep = names[i];
        }
        int len;
        len = i; //好友长度不超过10个好友
        for( i = 0;i < len;i++){  //将数据添加到集合中
            //System.out.println("第"+i+"个:--"+names[i]+"--");
            friList.add(new Fri(imageIds[i],names[i]));  //将图片id和对应name存储到一起
        }
        //添加新的好友后可以再friList.add(newXXX);

    }

    private void findfris(final String num) {
        new Thread(){
            public void run() {
                try{
                    addFriendUtils adf = new addFriendUtils();
                    if(num.equals("3")) {  // 查找好友信息
                        names = adf.findserver(id, null, "3");
                    }
                    else if(num.equals("4")){   //查看好友添加请求信息,获得被邀请好友姓名列表
                        res = adf.findserver(id,null,num);
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }.start();
    }

    //  准备获取位置信息
    private void prepareLocatingService() {
        // || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER
        new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("消息框")
                .setMessage("请先打开定位服务")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //定位服务设置意图
                        Intent intent = new Intent(
                                Settings.ACTION_LOCATION_SOURCE_SETTINGS
                        );
                        startActivityForResult(intent,LOCATION_SETTING_REQUEST_CODE);
                    }
                }).show();
    }

    @Override  //有返回值调用的回调
    protected void onActivityResult(int requestCode, int resultCode, @NonNull Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == LOCATION_SETTING_REQUEST_CODE){
            prepareLocatingService();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        switch (requestCode){
            case 1:
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    prepareLocatingService();
                }else{
                    Toast.makeText(this,"没有授予定位权限",Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }

    //  开启服务
    private void serviceStart() {
        conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                //  获取代理对象
                Service_sentLocTag.idBinder idBinder = (Service_sentLocTag.idBinder) service;
                //  调用代理方法
                idBinder.MyMethod();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                //  断开服务连接
            }
        };
        Intent intent1 = new Intent(getApplicationContext(), Service_sentLocTag.class); // 显示调用服务意图
        intent1.putExtra("id",id);
        System.out.println("MainAc+serStart："+id);
        intent1.setPackage("com.example.login_server.service_saveLoc");
        bindService(intent1,conn,BIND_AUTO_CREATE);
    }

    //  mune相关
    //  重写此方法，在Activity中使用菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.user_menu,menu);  //第一个参数指定创建菜单资源文件，第二个参数指定菜单项添加到哪一个menu对象
        return true;  //true表示允许显示创建的菜单
    }
    //重写此方法定义菜单响应事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.addfriends://点击了添加好友
                Intent intent = new Intent(this,AddFriend.class);
                intent.putExtra("id",id);  //向下一个页面传参
                startActivity(intent);
                break;
            case R.id.judclose: //判断是否邻近

                break;
             case R.id.back: //退出，回到登录页面--考虑实现服务器退出（通知服务器登录及退出以实现前面的异步通信）
                 finish();//结束当前页面
                 break;
         }
         return true;
    }
}