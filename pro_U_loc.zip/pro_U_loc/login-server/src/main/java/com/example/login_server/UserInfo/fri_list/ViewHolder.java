package com.example.login_server.UserInfo.fri_list;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
        ImageView image;
        TextView name;
}

