package com.example.login_server.loginInfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.login_server.R;
import com.example.login_server.UserInfo.UserActivity;

public class SignActivity extends AppCompatActivity {
    public static SignActivity signtivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        signtivity = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        Button sign = findViewById(R.id.sign_sign);
        final EditText name1 = findViewById(R.id.sign_name);
        final EditText password1 = findViewById(R.id.sign_password);

        //注册
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = name1.getText().toString();
                String password = password1.getText().toString();
                if(name == null || name.equals(""))
                    Toast.makeText(SignActivity.this,"昵称未填写！",Toast.LENGTH_LONG).show();
                else if(password == null || password.equals("")){
                    Toast.makeText(SignActivity.this,"密码未填写！",Toast.LENGTH_LONG).show();
                }
                else {
                  SignTask signtask = new SignTask();
                  signtask.execute(name,password);
                    signtask.setMsgRes(new MessageResponse() {
                        @Override
                        public void onReceivedSuccess(String id) {
                            jumptoUser(id);
                        }
                    });
                }
            }
        });

    }

    private void jumptoUser(String id){
        Intent intent = new Intent(this, UserActivity.class);
        intent.putExtra("id",id);  //向下一个页面传参
        startActivity(intent);
    }

}
