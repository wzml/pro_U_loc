package com.example.login_server.loginInfo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.login_server.R;
import com.example.login_server.UserInfo.UserActivity;

public class MainActivity extends AppCompatActivity {
    public static MainActivity mactivity;
    //public static Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mactivity = this;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button login = findViewById(R.id.login);
        Button sign = findViewById(R.id.sign);
        final EditText id = findViewById(R.id.id);

        final EditText password = findViewById(R.id.password);

        ImageView iv;
        String fileName = "";

        //登录
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String id1 = id.getText().toString();
                String password1 = password.getText().toString();
                try{
                    MyTask myTask = new MyTask();
                    myTask.execute(id1,password1);
                    myTask.setMsgRes(new MessageResponse() {
                        @Override
                        public void onReceivedSuccess(String name) {
                            if(!name.equals("")){
                                jumptoUser(id1);
                            }
                        }
                    });

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        //进入注册页面
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jumptoSign();
            }
        });

    }
    private void jumptoSign(){
        Intent intent = new Intent(this,SignActivity.class);
        startActivity(intent);
    }

    private void jumptoUser(String id){
        Intent intent = new Intent(this, UserActivity.class);
        intent.putExtra("id",id);  //向下一个页面传参
        startActivity(intent);
    }

}
