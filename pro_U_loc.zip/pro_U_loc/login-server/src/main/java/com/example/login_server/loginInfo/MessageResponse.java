package com.example.login_server.loginInfo;

public interface MessageResponse {
    void onReceivedSuccess(String name);
}
