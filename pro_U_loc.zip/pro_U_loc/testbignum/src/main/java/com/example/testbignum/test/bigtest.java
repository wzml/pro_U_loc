package com.example.testbignum.test;

import java.math.BigInteger;

public class bigtest {
    public static void main(String[] args){
        //Scanner s = new Scanner(System.in);
        String str = "981145611331336492272075765433436969079895053417314256701166191570572651304538152921873131048866194648648706663948709137272031151543192112419746424199";
        //System.out.println("Bignum:");
        //str = s.next();
        BigInteger num = new BigInteger(str);
        System.out.println("p:"+num);
        str = "";
}
}
